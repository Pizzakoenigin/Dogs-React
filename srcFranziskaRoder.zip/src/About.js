export default function About () {
    return(
        <div>   	    
            <h2>
        	    About
            </h2>

            <p>
                Here goes some Text
            </p>
        </div>
    )
}