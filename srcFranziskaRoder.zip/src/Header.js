export default function Header() {
    return (
      <h1 id='header'>Dogs 🐕🐶🐕‍🦺</h1>
    )
  }